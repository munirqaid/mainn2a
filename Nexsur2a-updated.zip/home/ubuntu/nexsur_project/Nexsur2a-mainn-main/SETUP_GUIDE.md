# دليل الإعداد والتشغيل - Nexora Platform

## المشكلة: حجم node_modules كبير جداً

ملف `node_modules` يحتوي على آلاف الملفات والمجلدات، مما يجعل من الصعب تحميله على GitHub. الحل هو استخدام ملف `.gitignore` لتجاهل هذا المجلد، وإعادة تثبيت المكتبات عند الحاجة.

---

## الحل الموصى به

### الخطوة 1: إنشاء ملف `.gitignore` (إذا لم يكن موجوداً)

تأكد من وجود ملف `.gitignore` في جذر المشروع يحتوي على:

```
# Dependencies
node_modules/
.pnpm-store/

# Environment variables
.env
.env.local
.env.*.local

# Logs
logs/
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Build
dist/
build/

# Uploads
public/uploads/
```

### الخطوة 2: حذف مجلد `node_modules` (اختياري)

إذا كان مجلد `node_modules` موجوداً وتريد تحميل المشروع على GitHub:

```bash
rm -rf node_modules
```

### الخطوة 3: تحميل المشروع على GitHub

بعد حذف `node_modules` وإضافة `.gitignore`، يمكنك تحميل المشروع على GitHub بدون مشاكل الحجم.

### الخطوة 4: إعادة تثبيت المكتبات عند الحاجة

عندما تريد تشغيل المشروع على جهاز جديد:

**الخيار 1: استخدام npm**
```bash
npm install
npm start
```

**الخيار 2: استخدام pnpm (أسرع وأخف)**
```bash
pnpm install
pnpm start
```

---

## متطلبات التشغيل

1. **Node.js** (الإصدار 16 أو أحدث)
2. **npm** أو **pnpm** (مدير الحزم)
3. **MongoDB** (قاعدة بيانات سحابية أو محلية)
4. **متصفح ويب حديث** (Chrome, Firefox, Safari, Edge)

---

## التبعيات المستخدمة

جميع التبعيات المطلوبة موجودة في ملف `package.json`:

```json
{
  "dependencies": {
    "bcryptjs": "^2.4.3",        // تشفير كلمات المرور
    "cors": "^2.8.5",            // السماح بطلبات من نطاقات مختلفة
    "dotenv": "^16.3.1",         // قراءة متغيرات البيئة من .env
    "drizzle-orm": "^0.27.0",    // ORM لـ SQLite
    "express": "^4.18.2",        // إطار العمل للخادم
    "jsonwebtoken": "^9.0.0",    // توليد والتحقق من التوكنات
    "mongoose": "^9.0.0",        // ODM لـ MongoDB
    "multer": "^1.4.5-lts.1",    // تحميل الملفات
    "sqlite": "^5.0.1",          // قاعدة بيانات SQLite
    "sqlite3": "^5.1.6",         // محرك SQLite
    "uuid": "^9.0.1"             // توليد معرفات فريدة
  }
}
```

---

## خطوات التشغيل

### 1. استنساخ المشروع (Clone)

```bash
git clone https://github.com/your-username/Nexsur2a.git
cd Nexsur2a-mainn-main
```

### 2. تثبيت المكتبات

```bash
npm install
# أو
pnpm install
```

### 3. إعداد متغيرات البيئة

تأكد من وجود ملف `.env` في جذر المشروع بالمحتوى التالي:

```env
MONGO_URI="mongodb+srv://username:password@cluster.mongodb.net/?retryWrites=true&w=majority"
PORT=3000
JWT_SECRET="your-secret-key-here"
```

**ملاحظة:** استبدل `MONGO_URI` برابط الاتصال الخاص بك.

### 4. تشغيل الخادم

```bash
npm start
# أو للتطوير (مع إعادة تحميل تلقائية)
npm run dev
```

يجب أن تظهر رسالة:
```
🚀 Nexora Server running on http://localhost:3000
📱 API available at http://localhost:3000/api
MongoDB Connected Successfully!
```

### 5. فتح المتصفح

انتقل إلى:
```
http://localhost:3000
```

---

## حل بديل: استخدام Docker (اختياري)

إذا كنت تريد تشغيل المشروع بدون الحاجة لتثبيت Node.js محلياً، يمكنك استخدام Docker.

### إنشاء ملف `Dockerfile`

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
```

### تشغيل Docker

```bash
docker build -t nexora .
docker run -p 3000:3000 --env-file .env nexora
```

---

## استكشاف الأخطاء

### الخطأ: "Cannot find module 'express'"

**الحل:** قم بتثبيت المكتبات:
```bash
npm install
```

### الخطأ: "MONGO_URI is not defined"

**الحل:** تأكد من وجود ملف `.env` وأنه يحتوي على `MONGO_URI`.

### الخطأ: "Port 3000 is already in use"

**الحل:** غير المنفذ في ملف `.env`:
```env
PORT=3001
```

### الخطأ: "MongoDB connection failed"

**الحل:** تأكد من:
1. صحة رابط الاتصال بـ MongoDB
2. أن قاعدة البيانات متاحة على الإنترنت (إذا كنت تستخدم MongoDB Atlas)
3. أن عنوان IP الخاص بك مضاف إلى قائمة السماح في MongoDB Atlas

---

## الملفات المهمة

| الملف | الوصف |
| :--- | :--- |
| `server.js` | نقطة الدخول الرئيسية للخادم |
| `.env` | متغيرات البيئة (MONGO_URI, PORT, JWT_SECRET) |
| `package.json` | التبعيات والمكتبات المستخدمة |
| `api/` | مسارات API (auth, posts, messages, إلخ) |
| `database/` | اتصال قاعدة البيانات والنماذج |
| `public/` | ملفات الواجهة الأمامية (HTML, CSS, JS) |

---

## الخطوات التالية

بعد تشغيل المشروع بنجاح:

1. اختبر وظيفة تسجيل الدخول والتسجيل (راجع `AUTHENTICATION_GUIDE.md`)
2. استكشف الميزات الأخرى (المنشورات، المراسلة، إلخ)
3. أضف ميزات جديدة حسب احتياجاتك

---

## الدعم والمساعدة

إذا واجهت أي مشاكل، يرجى:
1. مراجعة رسائل الخطأ في console
2. التحقق من ملف `.env`
3. التأكد من تشغيل MongoDB
4. فتح issue على GitHub
